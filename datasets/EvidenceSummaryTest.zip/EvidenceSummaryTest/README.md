
the interpretation of documents
-./abstractResult is the abstract of the literature
-./classifierResult is the result of sentence classification
-./manualResult is the gold standard marked by experts
-Original text in ./paper
-./RR3Result is the abstract of RR3 for the literature